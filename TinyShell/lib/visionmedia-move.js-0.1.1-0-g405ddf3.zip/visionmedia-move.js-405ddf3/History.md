
0.1.1 / 2011-12-10 
==================

  * Revert "Changed CSS property transition-properties to transition-property"

0.1.0 / 2011-11-16 
==================

  * Added more cubic-bezier ease functions [onirame]

0.0.4 / 2011-10-25 
==================

  * Remove resets in duration timeout causing undesired behaviour
  * Changed CSS property transition-properties to transition-property

0.0.3 / 2011-08-27 
==================

  * Added: allow passing of element to `move()`

0.0.2 / 2011-06-04 
==================

  * Added map of properties and defaults for numeric values
  * Fixed FireFox support [bluntworks]
  * Fixed easing example with html doctype
  * Fixed second notation for delay / duration
  * Fixed duration / delay, append "ms"

0.0.1 / 2011-06-01 
==================

  * Initial release
